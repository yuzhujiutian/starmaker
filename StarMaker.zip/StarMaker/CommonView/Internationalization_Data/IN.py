# coding=utf-8
IN = {}
IN["Personal_info"] = "व्यक्तिगत जानकारी"
IN["Album"] = "एलबम"
IN["Top_Fans"] = "शीर्ष प्रशंसक"
IN["Contribute"] = "योगदान दें"
IN["Store"] = "स्टोर"
IN["Private"] = "निजी"
IN["Select_Your_Gender"] = "अपना लिंग चुनें"
IN["Man"] = "पुरुष"
IN["Woman"] = "महिला"







