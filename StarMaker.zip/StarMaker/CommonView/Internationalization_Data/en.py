# coding=utf-8
en = {}
en["Personal_info"] = "Personal info"
en["Album"] = "Album"
en["Top_Fans"] = "Top Fans"
en["Contribute"] = "Contribute"
en["Store"] = "Store"
en["Private"] = "Private"
en["Select_Your_Gender"] = "Select Your Gender"
en["Man"] = "Man"
en["Woman"] = "Woman"

