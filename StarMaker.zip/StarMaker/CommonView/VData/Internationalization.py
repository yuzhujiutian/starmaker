# coding=utf-8
# ----------
# 首页
# ----------
Popular_English = "POPULAR"
Popular_Hindi = "लोकप्रिय"
