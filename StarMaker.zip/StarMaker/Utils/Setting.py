# coding=utf-8

# IP/端口
desired_IP = 4721

# 配置信息
PlatformName = "Android"
# AutomationName = "appium"
AutomationName = "uiautomator2"
AutoGrantPermissions = True
UnicodeKeyboard = True
ResetKeyboard = True
NoReset = True
AppActivity = "com.ushowmedia.starmaker.activity.SplashActivity"

# 设备信息(数据来源：GetDevicesInfo)
DeviceCount = 2
PlatformVersion = ['7.0', '5.0']
Device = ['SM_G570F', 'SM_G530H']
DeviceName = ['on5xelte', 'fortunave3g']

